Demo notes:
- Open `streamlit_app.py` using Streamlit.
- Use the sidebar to upload support docs (or rely on bundled assets).
- Click 'Build KB'.
- Ask for test cases (e.g., 'discount code', 'form validation').
- Select a generated test case and click 'Generate Selenium Script'.
- Copy the script, update the path to `checkout.html`, and run with your local Selenium + chromedriver.
